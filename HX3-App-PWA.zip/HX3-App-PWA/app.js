'use strict';

import {
  openDB, hasArchive, getTree, getFileBlob, clearArchive,
  importerZip, estimerEspace
} from './storage.js';
import * as viewer from './viewer.js';

const state = { db: null, tree: null, tab: 'chapitres', chapitre: null };

const el = {
  importScreen: document.getElementById('importScreen'),
  fileInput: document.getElementById('fileInput'),
  importBtn: document.getElementById('importBtn'),
  importProgress: document.getElementById('importProgress'),
  barFill: document.getElementById('barFill'),
  progressLabel: document.getElementById('progressLabel'),
  importError: document.getElementById('importError'),
  app: document.getElementById('app'),
  content: document.getElementById('content'),
  title: document.getElementById('appTitle'),
  backBtn: document.getElementById('backBtn'),
  menuBtn: document.getElementById('menuBtn'),
  breadcrumb: document.getElementById('breadcrumb'),
  tabbar: document.getElementById('tabbar'),
  viewerClose: document.getElementById('viewerClose'),
  viewerDownload: document.getElementById('viewerDownload'),
  sheetBackdrop: document.getElementById('sheetBackdrop'),
  replaceBtn: document.getElementById('replaceBtn'),
  storageBtn: document.getElementById('storageBtn'),
  sheetCancel: document.getElementById('sheetCancel'),
  replaceInput: document.getElementById('replaceInput'),
};

const TAB_LABEL = { chapitres: 'Chapitres', documents: 'Documents', ds: 'DS' };
const ICONS = {
  chevron: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  pdf: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h7l4 4v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z" fill="currentColor" opacity=".18"/><path d="M14 3v4h4" fill="none" stroke="currentColor" stroke-width="1.6"/><text x="12" y="17" font-size="6" font-weight="700" text-anchor="middle" fill="currentColor" font-family="sans-serif">PDF</text></svg>',
};

// ---------------------------------------------------------------------------
// Démarrage
// ---------------------------------------------------------------------------
async function init() {
  state.db = await openDB();
  const present = await hasArchive(state.db);
  if (present) {
    state.tree = await getTree(state.db);
    demarrerApp();
  } else {
    afficherImport();
  }

  // Import initial
  el.fileInput.addEventListener('change', (e) => lancerImport(e.target.files[0], false));
  // Remplacement
  el.replaceInput.addEventListener('change', (e) => lancerImport(e.target.files[0], true));

  // Onglets & navigation
  el.tabbar.querySelectorAll('.tab').forEach(btn =>
    btn.addEventListener('click', () => switchTab(btn.dataset.tab)));
  el.backBtn.addEventListener('click', goBack);

  // Menu / feuille d'options
  el.menuBtn.addEventListener('click', () => toggleSheet(true));
  el.sheetCancel.addEventListener('click', () => toggleSheet(false));
  el.sheetBackdrop.addEventListener('click', (e) => { if (e.target === el.sheetBackdrop) toggleSheet(false); });
  el.replaceBtn.addEventListener('click', () => { toggleSheet(false); el.replaceInput.click(); });
  el.storageBtn.addEventListener('click', afficherEspace);

  // Lecteur
  el.viewerClose.addEventListener('click', viewer.fermer);
  el.viewerDownload.addEventListener('click', viewer.telecharger);

  // Bouton retour matériel Android
  history.pushState({ root: true }, '');
  window.addEventListener('popstate', onPopState);
}

function onPopState() {
  if (viewer.estOuvert()) { viewer.fermer(); history.pushState({ root: true }, ''); return; }
  if (!el.sheetBackdrop.hidden) { toggleSheet(false); history.pushState({ root: true }, ''); return; }
  if (state.tab === 'chapitres' && state.chapitre) { goBack(); history.pushState({ root: true }, ''); return; }
  history.pushState({ root: true }, '');
}

// ---------------------------------------------------------------------------
// Import
// ---------------------------------------------------------------------------
function afficherImport() {
  el.importScreen.hidden = false;
  el.app.hidden = true;
}

async function lancerImport(file, remplacement) {
  if (!file) return;

  if (remplacement) {
    // Bascule sur l'écran d'import pour montrer la progression
    afficherImport();
  }
  el.importBtn.style.display = 'none';
  el.importError.hidden = true;
  el.importProgress.hidden = false;

  try {
    const tree = await importerZip(file, (frac, txt) => {
      el.barFill.style.width = Math.round(frac * 100) + '%';
      el.progressLabel.textContent = txt;
    });
    state.tree = tree;
    state.tab = 'chapitres';
    state.chapitre = null;
    await new Promise(r => setTimeout(r, 300));
    demarrerApp();
  } catch (e) {
    el.importProgress.hidden = true;
    el.importBtn.style.display = '';
    el.importError.hidden = false;
    el.importError.textContent = e.message || 'Échec de l\'import.';
  } finally {
    el.fileInput.value = '';
    el.replaceInput.value = '';
  }
}

function demarrerApp() {
  el.importScreen.hidden = true;
  el.app.hidden = false;
  // réinitialise l'écran d'import pour un éventuel remplacement futur
  el.importBtn.style.display = '';
  el.importProgress.hidden = true;
  el.barFill.style.width = '0%';
  render();
}

// ---------------------------------------------------------------------------
// Navigation entre onglets
// ---------------------------------------------------------------------------
function switchTab(tab) {
  if (tab === state.tab && !state.chapitre) return;
  state.tab = tab;
  state.chapitre = null;
  el.tabbar.querySelectorAll('.tab').forEach(b =>
    b.setAttribute('aria-current', b.dataset.tab === tab ? 'true' : 'false'));
  el.content.scrollTop = 0;
  render();
}

function goBack() {
  if (state.tab === 'chapitres' && state.chapitre) {
    state.chapitre = null;
    el.content.scrollTop = 0;
    render();
  }
}

async function ouvrirPdf(chemin, titre) {
  const blob = await getFileBlob(state.db, chemin);
  if (!blob) { alert('Fichier introuvable dans l\'archive.'); return; }
  const nom = chemin.split('/').pop();
  viewer.ouvrir(blob, titre, nom);
}

// ---------------------------------------------------------------------------
// Rendu
// ---------------------------------------------------------------------------
function render() {
  const inChapter = state.tab === 'chapitres' && state.chapitre;
  el.backBtn.hidden = !inChapter;
  if (state.tab === 'chapitres') renderChapitres();
  else if (state.tab === 'documents') renderDocuments();
  else renderDS();
}

function setHeader(title, crumbs) {
  el.title.textContent = title;
  if (crumbs && crumbs.length) {
    el.breadcrumb.hidden = false;
    el.breadcrumb.innerHTML = crumbs.map((c, i) => {
      const last = i === crumbs.length - 1;
      const sep = i > 0 ? '<span class="sep">›</span>' : '';
      return `${sep}<span class="${last ? 'current' : 'crumb'}">${escapeHtml(c)}</span>`;
    }).join('');
  } else {
    el.breadcrumb.hidden = true;
    el.breadcrumb.innerHTML = '';
  }
}

function viewWrap(inner) { el.content.innerHTML = `<div class="view">${inner}</div>`; }

function renderChapitres() {
  const chapitres = state.tree.onglets.chapitres;
  if (state.chapitre) {
    const chap = chapitres.find(c => c.id === state.chapitre);
    if (!chap) { state.chapitre = null; return renderChapitres(); }
    setHeader(labelOf(chap.titre), [TAB_LABEL.chapitres, chap.titre]);
    viewWrap(`<div class="list">${chap.fichiers.map(pdfRow).join('')}</div>`);
    bindPdfRows();
    return;
  }
  setHeader('Chapitres', null);
  const rows = chapitres.map(chap => {
    const nb = chap.fichiers.length;
    return `<button class="row" data-chap="${escapeAttr(chap.id)}">
      <span class="row-icon chapter">${numOf(chap.titre)}</span>
      <span class="row-body">
        <span class="row-title">${escapeHtml(labelOf(chap.titre))}</span>
        <span class="row-sub">${nb} fichier${nb > 1 ? 's' : ''}</span>
      </span>
      <span class="row-chevron">${ICONS.chevron}</span>
    </button>`;
  }).join('');
  viewWrap(`<div class="list">${rows}</div>`);
  el.content.querySelectorAll('[data-chap]').forEach(r =>
    r.addEventListener('click', () => { state.chapitre = r.dataset.chap; el.content.scrollTop = 0; render(); }));
}

function renderDocuments() {
  setHeader('Documents', null);
  const docs = state.tree.onglets.documents;
  if (!docs.length) { viewWrap('<p class="empty">Aucun document.</p>'); return; }
  viewWrap(`<div class="list">${docs.map(pdfRow).join('')}</div>`);
  bindPdfRows();
}

function renderDS() {
  setHeader('Devoirs surveillés', null);
  const groupes = state.tree.onglets.ds;
  if (!groupes.length) { viewWrap('<p class="empty">Aucun devoir surveillé.</p>'); return; }
  const html = groupes.map(g =>
    `<div class="group-title">${escapeHtml(g.annee)}</div><div class="list">${g.fichiers.map(pdfRow).join('')}</div>`
  ).join('');
  viewWrap(html);
  bindPdfRows();
}

function pdfRow(f) {
  return `<button class="row" data-pdf="${escapeAttr(f.chemin)}" data-titre="${escapeAttr(f.titre)}">
    <span class="row-icon pdf">${ICONS.pdf}</span>
    <span class="row-body"><span class="row-title">${escapeHtml(f.titre)}</span></span>
    <span class="row-chevron">${ICONS.chevron}</span>
  </button>`;
}

function bindPdfRows() {
  el.content.querySelectorAll('[data-pdf]').forEach(r =>
    r.addEventListener('click', () => ouvrirPdf(r.dataset.pdf, r.dataset.titre)));
}

// ---------------------------------------------------------------------------
// Feuille d'options
// ---------------------------------------------------------------------------
function toggleSheet(open) { el.sheetBackdrop.hidden = !open; }

async function afficherEspace() {
  toggleSheet(false);
  const est = await estimerEspace();
  if (!est) { alert('Information d\'espace indisponible.'); return; }
  const mo = o => (o / (1024 * 1024)).toFixed(1);
  alert(`Espace utilisé par l'application : ${mo(est.usage)} Mo` +
    (est.quota ? `\nQuota disponible : environ ${mo(est.quota)} Mo` : ''));
}

// ---------------------------------------------------------------------------
// Utilitaires
// ---------------------------------------------------------------------------
function numOf(titre) { const m = titre.match(/^(\d+)/); return m ? m[1] : '•'; }
function labelOf(titre) { return titre.replace(/^\d+\s*·\s*/, ''); }
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function escapeAttr(s) { return escapeHtml(s); }

init();
