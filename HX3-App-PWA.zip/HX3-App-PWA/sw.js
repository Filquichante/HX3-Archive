'use strict';

// Met en cache toute la coquille de l'application, y compris les bibliothèques
// (dézippage + lecteur PDF), pour un fonctionnement 100 % hors-ligne.
// Les PDF ne transitent pas par ici : ils sont dans IndexedDB.
const CACHE = 'hx3-archive-v2';

const SHELL = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './storage.js',
  './viewer.js',
  './manifest.json',
  './lib/fflate.min.js',
  './lib/pdf.min.mjs',
  './lib/pdf.worker.min.mjs',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  event.respondWith(
    caches.match(req).then((cached) => {
      const network = fetch(req).then((res) => {
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
        }
        return res;
      }).catch(() => cached);
      return cached || network;
    })
  );
});
