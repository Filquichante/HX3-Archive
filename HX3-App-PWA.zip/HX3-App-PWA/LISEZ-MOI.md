# Archive HX3 — Application (PWA)

Application web installable pour parcourir et lire tes cours, documents et
devoirs surveillés. Tu **importes l'archive une seule fois** : elle est ensuite
enregistrée dans l'application, qui fonctionne **entièrement hors-ligne**.

## Fonctionnement

- Au premier lancement, l'app te demande de choisir ton fichier
  `HX3_Archive_2025-2026.zip`. Elle le décompresse et enregistre tout dans le
  navigateur (IndexedDB).
- Les lancements suivants sont instantanés : plus aucun import, plus aucun
  réseau nécessaire.
- Trois onglets : **Chapitres** (43 chapitres, deux niveaux), **Documents**
  (liste directe), **DS** (groupés par année, la plus récente en haut,
  numérotés dans l'ordre).
- Les PDF s'ouvrent dans un **lecteur intégré** (défilement vertical, pincement
  pour zoomer). Un bouton permet d'enregistrer un PDF si tu veux l'ouvrir
  ailleurs.
- Menu **⋮** en haut à droite : remplacer l'archive, voir l'espace utilisé.

## Mise en ligne sur GitHub Pages (depuis le téléphone)

Une PWA doit être servie en HTTPS. GitHub Pages le fait gratuitement.
L'archive (les 70 Mo de PDF) **ne va pas** sur GitHub : seule l'app y est
publiée. Les PDF, tu les importes depuis le téléphone au premier lancement.

1. **Crée un dépôt.** Sur github.com : bouton **+** → **New repository**.
   Nomme-le (ex. `hx3-archive`), garde-le **Public**, coche
   **Add a README**, puis **Create repository**.

2. **Envoie les fichiers de l'app.** Dans le dépôt : **Add file** →
   **Upload files**. Envoie **le contenu de ce dossier** (les fichiers
   `index.html`, `app.js`, etc. **et** les dossiers `lib/` et `icons/`).

   > Astuce mobile : l'upload web garde les sous-dossiers si tu sélectionnes
   > les fichiers avec leur arborescence. En cas de souci avec `lib/` et
   > `icons/`, l'appli **GitHub** (Android) rend l'envoi de dossiers plus
   > simple. L'important : conserver la structure
   > `lib/pdf.min.mjs`, `lib/pdf.worker.min.mjs`, `lib/fflate.min.js`,
   > `icons/…`.

   Valide avec **Commit changes**.

3. **Active Pages.** Onglet **Settings** → **Pages** → *Source* :
   **Deploy from a branch**, branche **main**, dossier **/ (root)**, **Save**.
   Après 1–2 minutes, l'URL apparaît :
   `https://<ton-pseudo>.github.io/hx3-archive/`.

4. **Installe sur le téléphone.** Ouvre cette URL dans **Chrome**, puis
   menu **⋮ → Ajouter à l'écran d'accueil**. L'app s'ouvre en plein écran.

5. **Importe l'archive.** Au premier lancement, appuie sur
   **Choisir l'archive (.zip)** et sélectionne ton
   `HX3_Archive_2025-2026.zip` (déjà sur le téléphone). L'app l'enregistre :
   c'est fait une bonne fois pour toutes.

## Remarques

- **Espace.** L'archive (~70 Mo) est stockée dans le navigateur. Si tu
  désinstalles l'app ou vides les données du site, il faudra réimporter le zip.
- **Mise à jour du contenu.** Le contenu est figé ; si un jour l'archive
  change, utilise **⋮ → Remplacer l'archive** avec le nouveau zip.
- **Lecteur PDF.** Le lecteur est intégré à l'app (technologie PDF.js). Ce
  choix est imposé par le fonctionnement hors-ligne : les fichiers vivant dans
  l'app, ils ne peuvent pas être délégués à un lecteur externe du téléphone.
