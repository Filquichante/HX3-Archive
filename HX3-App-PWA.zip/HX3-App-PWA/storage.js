'use strict';

// ---------------------------------------------------------------------------
// Stockage persistant (IndexedDB) : les PDF et l'arborescence sont enregistrés
// une seule fois, à l'import. Ensuite, tout est relu localement.
// ---------------------------------------------------------------------------

const DB_NAME = 'hx3-archive';
const DB_VERSION = 1;
const STORE_FILES = 'files';   // clé = chemin, valeur = Blob PDF
const STORE_META = 'meta';     // clé = 'tree' -> arborescence ; 'info' -> infos

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_FILES)) db.createObjectStore(STORE_FILES);
      if (!db.objectStoreNames.contains(STORE_META)) db.createObjectStore(STORE_META);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function tx(db, store, mode) {
  return db.transaction(store, mode).objectStore(store);
}

function idbGet(db, store, key) {
  return new Promise((resolve, reject) => {
    const r = tx(db, store, 'readonly').get(key);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}

function idbPut(db, store, key, val) {
  return new Promise((resolve, reject) => {
    const r = tx(db, store, 'readwrite').put(val, key);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
}

function idbClear(db, store) {
  return new Promise((resolve, reject) => {
    const r = tx(db, store, 'readwrite').clear();
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
}

async function hasArchive(db) {
  const tree = await idbGet(db, STORE_META, 'tree');
  return !!tree;
}

async function getTree(db) {
  return idbGet(db, STORE_META, 'tree');
}

async function getFileBlob(db, chemin) {
  return idbGet(db, STORE_FILES, chemin);
}

async function clearArchive(db) {
  await idbClear(db, STORE_FILES);
  await idbClear(db, STORE_META);
}

// ---------------------------------------------------------------------------
// Embellissement des noms (port de la logique Python)
// ---------------------------------------------------------------------------

function embellir(s) {
  s = s.replace(/([a-zàâäéèêëïîôöùûüç])([A-Z])/g, '$1 $2');
  s = s.replace(/([A-Za-z])(\d)/g, '$1 $2');
  s = s.replace(/(\d)([A-Za-z])/g, '$1 $2');
  return s.trim();
}

function titreFichier(fn) {
  const base = fn.toLowerCase().endsWith('.pdf') ? fn.slice(0, -4) : fn;
  return embellir(base);
}

function chapTitre(dirname) {
  const m = dirname.match(/^(\d+)-(.*)$/);
  if (m) return `${m[1]} · ${embellir(m[2])}`;
  return embellir(dirname);
}

// ---------------------------------------------------------------------------
// Construction de l'arborescence à partir de la liste des chemins du zip
// ---------------------------------------------------------------------------

function construireArborescence(chemins) {
  // On repère le préfixe racine "HX3 Archive .../" s'il existe.
  const pdfs = chemins.filter(p => p.toLowerCase().endsWith('.pdf'));

  // Détecte un dossier racine commun (ex. "HX3 Archive 2025-2026/")
  let racine = '';
  const premiers = pdfs.map(p => p.split('/')[0]);
  if (premiers.length && premiers.every(x => x === premiers[0]) && pdfs.every(p => p.includes('/'))) {
    racine = premiers[0] + '/';
  }
  const rel = pdfs.map(p => (racine && p.startsWith(racine)) ? p.slice(racine.length) : p);

  // --- chapitres ---
  const chapMap = new Map();
  for (const r of rel) {
    const parts = r.split('/');
    if (parts[0] === 'chapitres' && parts.length === 3) {
      const chap = parts[1], fichier = parts[2];
      if (!chapMap.has(chap)) chapMap.set(chap, []);
      chapMap.get(chap).push(fichier);
    }
  }
  const numPrefix = d => { const m = d.match(/^(\d+)/); return m ? parseInt(m[1], 10) : 0; };
  const chapitres = [...chapMap.keys()]
    .sort((a, b) => numPrefix(a) - numPrefix(b) || a.localeCompare(b))
    .map(chap => ({
      id: chap,
      titre: chapTitre(chap),
      fichiers: chapMap.get(chap).sort().map(f => ({
        titre: titreFichier(f),
        chemin: `${racine}chapitres/${chap}/${f}`
      }))
    }));

  // --- documents ---
  const documents = rel
    .filter(r => r.startsWith('documents/') && r.split('/').length === 2)
    .sort()
    .map(r => ({ titre: titreFichier(r.split('/')[1]), chemin: `${racine}${r}` }));

  // --- ds : groupés par année (récent en haut), numéro croissant ---
  const dsFiles = rel.filter(r => r.startsWith('ds/') && r.split('/').length === 2)
    .map(r => r.split('/')[1]);
  const annees = new Map();
  const pat = /^DS\s*0*(\d+)\s*\((\d{4}-\d{4})\)/i;
  for (const fn of dsFiles) {
    const m = fn.match(pat);
    if (m) {
      const num = parseInt(m[1], 10), annee = m[2];
      if (!annees.has(annee)) annees.set(annee, []);
      annees.get(annee).push({ num, fn });
    }
  }
  const ds = [...annees.keys()].sort().reverse().map(annee => ({
    annee,
    fichiers: annees.get(annee).sort((a, b) => a.num - b.num).map(({ num, fn }) => ({
      titre: `DS ${String(num).padStart(2, '0')}`,
      chemin: `${racine}ds/${fn}`
    }))
  }));

  return {
    onglets: { chapitres, documents, ds },
    _racine: racine
  };
}

// ---------------------------------------------------------------------------
// Import : dézippe le fichier, enregistre chaque PDF + l'arborescence
// onProgress(fraction 0..1, texte)
// ---------------------------------------------------------------------------

async function importerZip(file, onProgress) {
  onProgress(0.02, 'Lecture de l\'archive…');
  const buf = new Uint8Array(await file.arrayBuffer());

  onProgress(0.08, 'Décompression…');
  // fflate.unzipSync est synchrone ; on le lance après un tick pour laisser
  // l'UI se rafraîchir.
  await new Promise(r => setTimeout(r, 30));

  let entries;
  try {
    entries = self.fflate.unzipSync(buf, {
      filter: f => f.name.toLowerCase().endsWith('.pdf')
    });
  } catch (e) {
    throw new Error('Archive illisible ou corrompue.');
  }

  const chemins = Object.keys(entries);
  if (!chemins.length) throw new Error('Aucun PDF trouvé dans l\'archive.');

  const tree = construireArborescence(chemins);

  const db = await openDB();
  await clearArchive(db);

  // Enregistre les PDF un par un, avec progression.
  const total = chemins.length;
  let done = 0;
  for (const chemin of chemins) {
    const data = entries[chemin];
    const blob = new Blob([data], { type: 'application/pdf' });
    await idbPut(db, STORE_FILES, chemin, blob);
    done++;
    if (done % 5 === 0 || done === total) {
      onProgress(0.1 + 0.88 * (done / total), `Enregistrement des fichiers… ${done}/${total}`);
      await new Promise(r => setTimeout(r, 0));
    }
  }

  await idbPut(db, STORE_META, 'tree', tree);
  await idbPut(db, STORE_META, 'info', {
    date: Date.now(),
    nbFichiers: total,
    nom: file.name
  });

  onProgress(1, 'Terminé');
  return tree;
}

async function estimerEspace() {
  if (navigator.storage && navigator.storage.estimate) {
    const est = await navigator.storage.estimate();
    return { usage: est.usage || 0, quota: est.quota || 0 };
  }
  return null;
}

export {
  openDB, hasArchive, getTree, getFileBlob, clearArchive,
  importerZip, estimerEspace
};
