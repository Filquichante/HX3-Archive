'use strict';

// Lecteur PDF intégré, basé sur PDF.js. Rend les pages dans un défilement
// vertical, avec pincement pour zoomer géré par le navigateur.

import * as pdfjsLib from './lib/pdf.min.mjs';
pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('./lib/pdf.worker.min.mjs', import.meta.url).href;

let currentTask = null;
let currentUrl = null;
let currentBlob = null;
let currentName = 'document.pdf';

const elViewer = document.getElementById('viewer');
const elPages = document.getElementById('viewerPages');
const elTitle = document.getElementById('viewerTitle');
const elLoader = document.getElementById('viewerLoader');

async function ouvrir(blob, titre, nomFichier) {
  currentBlob = blob;
  currentName = nomFichier || 'document.pdf';
  elTitle.textContent = titre || '';
  elPages.innerHTML = '';
  elLoader.hidden = false;
  elViewer.hidden = false;
  document.body.classList.add('viewer-open');

  if (currentUrl) { URL.revokeObjectURL(currentUrl); currentUrl = null; }
  currentUrl = URL.createObjectURL(blob);

  try {
    const data = new Uint8Array(await blob.arrayBuffer());
    currentTask = pdfjsLib.getDocument({ data });
    const pdf = await currentTask.promise;

    const largeur = Math.min(elPages.clientWidth || window.innerWidth, 1000);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    for (let n = 1; n <= pdf.numPages; n++) {
      const page = await pdf.getPage(n);
      const base = page.getViewport({ scale: 1 });
      const scale = (largeur - 16) / base.width;
      const viewport = page.getViewport({ scale });

      const canvas = document.createElement('canvas');
      canvas.className = 'pdf-page';
      canvas.width = Math.floor(viewport.width * dpr);
      canvas.height = Math.floor(viewport.height * dpr);
      canvas.style.width = viewport.width + 'px';
      canvas.style.height = viewport.height + 'px';
      elPages.appendChild(canvas);

      const ctx = canvas.getContext('2d');
      ctx.scale(dpr, dpr);
      await page.render({ canvasContext: ctx, viewport }).promise;

      if (n === 1) elLoader.hidden = true;
    }
    elLoader.hidden = true;
  } catch (e) {
    elLoader.hidden = true;
    elPages.innerHTML = '<p class="viewer-error">Impossible d\'afficher ce PDF.<br>Tu peux l\'enregistrer pour l\'ouvrir dans un autre lecteur.</p>';
  }
}

function fermer() {
  elViewer.hidden = true;
  document.body.classList.remove('viewer-open');
  elPages.innerHTML = '';
  if (currentTask) { currentTask.destroy?.(); currentTask = null; }
  if (currentUrl) { URL.revokeObjectURL(currentUrl); currentUrl = null; }
  currentBlob = null;
}

function telecharger() {
  if (!currentBlob) return;
  const url = URL.createObjectURL(currentBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = currentName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function estOuvert() { return !elViewer.hidden; }

export { ouvrir, fermer, telecharger, estOuvert };
